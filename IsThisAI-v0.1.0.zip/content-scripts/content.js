var content=(function(){"use strict";function k(i){return i}const v={commonPhrases:["it is important to note","it's worth noting","in conclusion","furthermore","moreover","additionally","delve into","utilize","leverage","comprehensive","robust","facilitate","implement","various","particular","significant","substantial","innovative","cutting-edge","state-of-the-art"],formalMaker:["one might argue","it could be said","in light of","with regard to","concerning the matter of"]};class x{analyzeText(e){const t=e.split(/\s+/).filter(s=>s.length>0),n=e.split(/[.!?]/).filter(s=>s.trim().length>0),o=t.length,r=new Set(t.map(s=>s.toLowerCase())).size,c=t.reduce((s,a)=>s+a.length,0)/o,l=o/n.length;return{avgWordLength:c,todalWords:o,uniqueWords:r,sentenceComplexity:l}}checkAIpattern(e){const t=e.toLowerCase();let n=0;const o=[];return v.commonPhrases.forEach(r=>{t.includes(r.toLowerCase())&&(n+=10,o.push(`Contains phrase: "${r}"`))}),v.formalMaker.forEach(r=>{t.includes(r.toLowerCase())&&(n+=8,o.push(`Formal structure: "${r}"`))}),{score:n,matches:o}}checkHumanPattern(e){let t=0;const n=[],o=["don't","won't","can't","it's","i'm","you're","we're","they're","isn't","aren't","weren't","haven't","hasn't","hadn't"],r=e.toLowerCase();let c=0;o.forEach(h=>{r.includes(h)&&c++}),c>2&&(t+=15,n.push(`Uses contractions (${c} found) - common in human writing`));const l=["lol","haha","omg","tbh","btw","yeah","nah","gonna","wanna","kinda","sorta","pretty much","you know","i mean","like,","well,","honestly","basically","literally","actually","seriously"];let s=0;l.forEach(h=>{r.includes(h)&&s++}),s>1&&(t+=20,n.push(`Informal language detected (${s} expression) - typical human style`));const a=(e.match(/\?/g)||[]).length,d=(e.match(/!/g)||[]).length;(a>1||d>1)&&(t+=10,n.push("Emotional punctuation - suggests human writer"));const b=e.split(/[.!?]+/).filter(h=>h.trim().length>0);b.filter(h=>h.trim().split(/\s+/).length<8).length>b.length*.3&&(t+=12,n.push("Many short sentences - conversational human style"));const y=e.match(/[a-z][A-Z]/g);return y&&y.length>0&&(t+=8,n.push("Irregular formatting - human imperfection")),{score:t,matches:n}}checkUniformity(e){let t=0,n="";return e.uniqueWords/e.todalWords>.75&&(t+=15,n="Exeptionally high vocabulary diversity (AI tends to avoid repetition)"),e.sentenceComplexity>15&&e.sentenceComplexity<25&&(t+=12,n+=n?"|":"",n+="Very consistent sentence structure"),e.avgWordLength>5.5&&e.avgWordLength<6.5&&(t+=8,n+=n?"|":"",n+="Unusually consistent word length"),{score:t,reason:n}}checkTextFlow(e){let t=0,n="";const r=e.split(/[.!?]+/).filter(s=>s.trim().length>0).map(s=>s.trim().split(/\s+/).length),c=r.reduce((s,a)=>s+a,0)/r.length,l=r.reduce((s,a)=>s+Math.pow(a-c,2),0)/r.length;return l<20?(t+=15,n="Very uniform sentence length - AI pattern"):l>80&&(t-=10,n="Varied sentence structure - human pattern"),{score:t,reason:n}}detect(e){if(e.length<50)return{isAI:!1,confidance:0,reason:["text too shorts to analyze (minimum 50 characters)"],category:"text"};const t=this.analyzeText(e),n=this.checkAIpattern(e),o=this.checkUniformity(t),r=this.checkHumanPattern(e),c=this.checkTextFlow(e);let l=n.score+o.score+c.score;l-=r.score;let s=Math.max(0,Math.min(100,l));const a=[];return r.matches.length>0&&a.push(...r.matches),n.matches.length>0&&a.push(...n.matches),o.reason&&a.push(o.reason),c.reason&&a.push(c.reason),a.length==0&&a.push("Analysis inconclusive - text appears neutral"),{isAI:s>55,confidance:Math.round(s),reason:a,category:"text"}}}const I={matches:["<all_urls>"],main(){console.log("IsThisAI content script loaded on:",window.location.href),chrome.runtime.onMessage.addListener((e,t,n)=>{if(console.log("Content script received message:",e),e.action==="analyzeText")try{const r=new x().detect(e.text);console.log("Detection result:",r),i(e.text,r),n({success:!0})}catch(o){console.error("Error analyzing text:",o),n({success:!1,error:String(o)})}return!0});function i(e,t){const n=document.getElementById("isthisai-modal");n&&n.remove();const o=document.createElement("div");o.id="isthisai-modal",Object.assign(o.style,{position:"fixed",top:"0",left:"0",width:"100%",height:"100%",background:"rgba(0, 0, 0, 0.75)",display:"flex",justifyContent:"center",alignItems:"center",zIndex:"2147483647",fontFamily:"system-ui, -apple-system, sans-serif"});const r=document.createElement("div");Object.assign(r.style,{background:"white",borderRadius:"16px",padding:"30px",maxWidth:"500px",maxHeight:"80vh",overflowY:"auto",boxShadow:"0 20px 60px rgba(0, 0, 0, 0.4)"});const c=e.length>200?e.substring(0,200)+"...":e;r.innerHTML=`
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
          <h2 style="margin: 0; font-size: 24px; font-weight: 700; color: #1a1a1a;">
            IsThisAI? 🦠
          </h2>
          <button id="isthisai-close" style="
            background: none;
            border: none;
            font-size: 32px;
            cursor: pointer;
            color: #666;
            line-height: 1;
            padding: 0;
            width: 40px;
            height: 40px;
          ">×</button>
        </div>

        <div style="
          background: #f8f9fa;
          padding: 15px;
          border-radius: 8px;
          margin-bottom: 20px;
          max-height: 120px;
          overflow-y: auto;
          font-size: 13px;
          color: #555;
          border: 1px solid #e0e0e0;
          line-height: 1.5;
        ">
          <strong style="color: #333;">Analyzed Text:</strong><br>
          ${c.replace(/</g,"&lt;").replace(/>/g,"&gt;")}
        </div>

        <div style="
          background: ${t.isAI?"#fee":"#efe"};
          border: 2px solid ${t.isAI?"#e74c3c":"#27ae60"};
          border-radius: 12px;
          padding: 20px;
          margin-bottom: 15px;
        ">
          <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
            <span style="font-size: 36px;">${t.isAI?"🤖":"👤"}</span>
            <div>
              <div style="font-size: 18px; font-weight: 700; color: ${t.isAI?"#c0392b":"#229954"};">
                ${t.isAI?"Likely AI-Generated":"Likely Human-Written"}
              </div>
              <div style="font-size: 13px; color: #666; margin-top: 4px;">
                Confidence: ${t.confidance}%
              </div>
            </div>
          </div>

          <div style="width: 100%; height: 10px; background: rgba(0,0,0,0.1); border-radius: 5px; overflow: hidden;">
            <div style="width: ${t.confidance}%; height: 100%; background: ${t.isAI?"#e74c3c":"#27ae60"};"></div>
          </div>
        </div>

        ${t.reason.length>0?`
          <div style="margin-bottom: 20px;">
            <div style="font-size: 14px; font-weight: 600; color: #333; margin-bottom: 10px;">
              Detection Indicators:
            </div>
            <ul style="margin: 0; padding-left: 20px; font-size: 13px; color: #555; line-height: 1.7;">
              ${t.reason.map(d=>`<li>${d.replace(/</g,"&lt;").replace(/>/g,"&gt;")}</li>`).join("")}
            </ul>
          </div>
        `:""}

        <div style="
          background: #fff3cd;
          border: 1px solid #ffc107;
          border-radius: 8px;
          padding: 12px;
          font-size: 12px;
          color: #856404;
          margin-bottom: 15px;
        ">
          <strong>⚠️ Note:</strong> This is a prototype. Results may not be 100% accurate.
        </div>

        <button id="isthisai-open-popup" style="
          width: 100%;
          padding: 14px;
          background: #4a90e2;
          color: white;
          border: none;
          border-radius: 8px;
          font-size: 14px;
          font-weight: 600;
          cursor: pointer;
        ">
          Open Full Extension
        </button>
      `,o.appendChild(r),document.body.appendChild(o),r.querySelector("#isthisai-close")?.addEventListener("click",()=>o.remove()),o.addEventListener("click",d=>{d.target===o&&o.remove()}),r.querySelector("#isthisai-open-popup")?.addEventListener("click",()=>{chrome.runtime.sendMessage({action:"openPopup"}),o.remove()});const a=d=>{d.key==="Escape"&&(o.remove(),document.removeEventListener("keydown",a))};document.addEventListener("keydown",a)}}},w=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function u(i,...e){}const E={debug:(...i)=>u(console.debug,...i),log:(...i)=>u(console.log,...i),warn:(...i)=>u(console.warn,...i),error:(...i)=>u(console.error,...i)};class m extends Event{constructor(e,t){super(m.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=t}static EVENT_NAME=f("wxt:locationchange")}function f(i){return`${w?.runtime?.id}:content:${i}`}function S(i){let e,t;return{run(){e==null&&(t=new URL(location.href),e=i.setInterval(()=>{let n=new URL(location.href);n.href!==t.href&&(window.dispatchEvent(new m(n,t)),t=n)},1e3))}}}class g{constructor(e,t){this.contentScriptName=e,this.options=t,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}static SCRIPT_STARTED_MESSAGE_TYPE=f("wxt:content-script-started");isTopFrame=window.self===window.top;abortController;locationWatcher=S(this);receivedMessageIds=new Set;get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return w.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,t){const n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){const n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){const t=requestAnimationFrame((...n)=>{this.isValid&&e(...n)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){const n=requestIdleCallback((...o)=>{this.signal.aborted||e(...o)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,o){t==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith("wxt:")?f(t):t,n,{...o,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),E.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:g.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(e){const t=e.data?.type===g.SCRIPT_STARTED_MESSAGE_TYPE,n=e.data?.contentScriptName===this.contentScriptName,o=!this.receivedMessageIds.has(e.data?.messageId);return t&&n&&o}listenForNewerScripts(e){let t=!0;const n=o=>{if(this.verifyScriptStartedEvent(o)){this.receivedMessageIds.add(o.data.messageId);const r=t;if(t=!1,r&&e?.ignoreFirstEvent)return;this.notifyInvalidated()}};addEventListener("message",n),this.onInvalidated(()=>removeEventListener("message",n))}}function C(){}function p(i,...e){}const T={debug:(...i)=>p(console.debug,...i),log:(...i)=>p(console.log,...i),warn:(...i)=>p(console.warn,...i),error:(...i)=>p(console.error,...i)};return(async()=>{try{const{main:i,...e}=I,t=new g("content",e);return await i(t)}catch(i){throw T.error('The content script "content" crashed on startup!',i),i}})()})();
content;